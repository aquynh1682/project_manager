<div id="container">
        <div id="header">
            <div class="container">
                <div class="logo">
                    <!--
                        <a href="index.html">K12</p></a>
                        -->
                    <a href="../index.php">
                        <img src="../anh/logo1.png" url="../index.php" alt="">
                    </a>
                </div>
            </div>
        </div>
    </div>