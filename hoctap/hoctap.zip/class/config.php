<?php
$dbserver = "localhost";
$username = "root";
$password = "";
$database = "k12-khmt";
?>