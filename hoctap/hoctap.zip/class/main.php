<div class="main">
        <div class="left"></div>
        <div class="center"></div>
        <div class="right">
            <h3>Môn Học</h3>
            <ul>
                <li><a href="math.php">Toán Học</a></li>
                <li><a href="vatly.php">Vật Lý</a></li>
                <li><a href="dialy.php">Địa Lý</a></li>
                <li><a href="english.php">Tiếng Anh</a></li>
                <li><a href="tonghop.php">Tổng Hợp</a></li>
                <li><a href="khoahocxahoi.php">Khoa Học Xã Hội</a></li>
                <li><a href="sinhhoc.php">Sinh Học</a></li>
                <li><a href="history.php">Lịch Sử</a></li>
                <li><a href="hoahoc.php">Hóa Học</a></li>

            </ul>
        </div>
       
    </div>