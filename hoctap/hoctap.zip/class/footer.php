<div id="footer">
    <div class="container">
        <div class="logo">
            <a href="../index.php">k12htht.xyz</a>
            <h3>Website thi và tạo đề thi trắc nghiệm online. Mang đến người dùng các chức năng tốt nhất cho việc học tập và giảng dậy.</h3>
        </div>
        <h2>Liên Hệ</h2>
        <div class="contac-info">
            <!-- <a href="#">Liên hệ</a> -->

            <ul>
                <li>
                    <div class="contac-icon">
                        <img src="../anh/mail.png" alt="">
                    </div>

                    <div class="contac-text">
                        <label>Email</label>
                        <pan class="text">HoTro@k12htht.xyz</pan>
                    </div>
                </li>

                <li>
                    <div class="contac-icon">
                        <img src="../anh/call.png" alt="">
                    </div>

                    <div class="contac-text">
                        <label>Call</label>
                        <pan class="text">0942 187 996</pan>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>