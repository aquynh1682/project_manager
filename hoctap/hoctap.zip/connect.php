<?php
    $conn = mysqli_connect('localhost', 'olirenwm_htht', '123456a@', 'olirenwm_htht');

    mysqli_set_charset($conn, 'utf8');
?>