
<div class="form-search" style="margin-top: 5px;">
    <input class="td-widget-search-input" placeholder="Nhập từ khóa để tìm kiếm..." type="text" value="" name="s" id="s" style="width: 400px;height: 40px;border-radius: 10px;border: 1px solid #999;">
    <input class="wpb_button wpb_btn-inverse btn" type="submit" id="searchsubmit" value="Tìm kiếm" style="height: 40px;border: 1px solid #999;">
</div>