<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$vnp_TmnCode = "1UBW9P7E"; //Mã website tại VNPAY 
$vnp_HashSecret = "AGNDRGBAGLMLEMQEMNGNNFGTMKNDBCZY"; //Chuỗi bí mật
$vnp_Url = "http://sandbox.vnpayment.vn/paymentv2/vpcpay.html";
$vnp_Returnurl = "http://k12htht.xyz/vnpay_php/vnpay_return.php";